function cnk:villager/add_loot_table {loot_table: "pearl_jam:standing_recipe"}
