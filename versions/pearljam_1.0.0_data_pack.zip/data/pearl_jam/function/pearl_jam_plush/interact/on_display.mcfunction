execute if entity @p[tag=pearl_jam.interact_pearl_jam_plush, distance=..20, predicate=cnk:sneaking] on passengers if entity @s[type=minecraft:item_display, tag=cnk.mr_kettle_item] on vehicle run return run function pearl_jam:pearl_jam_plush/item/clear
execute unless items entity @p[tag=pearl_jam.interact_pearl_jam_plush, distance=..20] weapon.mainhand * run return run playsound pearl_jam:item.plush.squeak block @a ~ ~ ~ 1 1
execute if items entity @p[tag=pearl_jam.interact_pearl_jam_plush, distance=..20] weapon.mainhand * run return run function pearl_jam:pearl_jam_plush/item/main
