execute unless block ~ ~ ~ #minecraft:trapdoors[half=bottom, open=false] unless block ~ ~ ~ #cnk:carpets unless block ~ ~ ~ #minecraft:slabs[type=bottom] run return run function pearl_jam:pearl_jam_plush/break/break
execute if score @s cnk.hit_count matches 1.. run function pearl_jam:pearl_jam_plush/break/check
