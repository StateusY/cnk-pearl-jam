execute if data storage cnk:temp block.data.components."minecraft:custom_data".cnk.block{type: "pearl_jam_plush"} run return run function pearl_jam:pearl_jam_plush/place
