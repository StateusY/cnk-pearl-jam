$summon item_display ~ ~ ~ {Tags:["pearl_jam.pearl_jam_plush","cnk.block","smithed.block","smithed.entity","smithed.strict"],transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],scale:[1.01f,1.01f,1.01f],translation:[0.0f,0.5f,0.0f]},item:{id:"minecraft:barrier",count:1,components:{"minecraft:item_name":"minecraft:barrier","minecraft:item_model":"pearl_jam:pearl_jam_plush_block","minecraft:custom_data":{"$jade:stack":{"id":"pearl_jam:pearl_jam_plush"}}}},Rotation:[$(rotation),0.0],Passengers:\
    [\
        {id:"minecraft:interaction",Tags:["pearl_jam.pearl_jam_plush_interaction","smithed.block","smithed.entity","smithed.strict"],height:1.2,width:0.8}\
    ]}
