playsound pearl_jam:item.plush.squeak block @a ~ ~ ~ 1 1
execute if data entity @s item.components run function pearl_jam:pearl_jam_plush/item/item_macro_components with entity @s item
execute unless data entity @s item.components run function pearl_jam:pearl_jam_plush/item/item_macro with entity @s item
kill @s